import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Componente para proteger rutas que requieren autenticación
export function ProtectedRoute() {
  const { isAuthenticated } = useAuth();
  
  // Si no está autenticado, redirigir a login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  // Si está autenticado, renderizar los componentes hijos
  return <Outlet />;
}

// Componente para proteger rutas que requieren un rol específico
export function RoleRoute({ requiredRole }) {
  const { isAuthenticated, hasRole, isBlocked } = useAuth();
  
  // Si no está autenticado, redirigir a login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  // Si está bloqueado, redirigir a página de bloqueo
  if (isBlocked()) {
    return <Navigate to="/blocked" replace />;
  }
  
  // Si no tiene el rol requerido, redirigir a página de acceso denegado
  if (!hasRole(requiredRole)) {
    return <Navigate to="/unauthorized" replace />;
  }
  
  // Si cumple todos los requisitos, renderizar los componentes hijos
  return <Outlet />;
}