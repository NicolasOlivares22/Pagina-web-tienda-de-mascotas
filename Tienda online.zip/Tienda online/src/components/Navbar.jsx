import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useContext } from 'react';
import { CartContext } from '../context/CartContext';

export default function Navbar() {
  const { isAuthenticated, user, hasRole, logout } = useAuth();
  const { cartItems } = useContext(CartContext) || { cartItems: [] };
  
  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  
  return (
    <nav className="navbar navbar-expand-lg navbar-dark" style={{backgroundColor: 'var(--primary-color)'}}>
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">
          <i className="bi bi-shop me-2"></i>
          PetShop Xano
        </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">Inicio</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/productos">Productos</Link>
            </li>
            
            {/* Menú para vendedores */}
            {hasRole('vendor') && (
              <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                  Vendedor
                </a>
                <ul className="dropdown-menu">
                  <li><Link className="dropdown-item" to="/vendedor">Dashboard</Link></li>
                  <li><Link className="dropdown-item" to="/vendedor/productos">Mis Productos</Link></li>
                  <li><Link className="dropdown-item" to="/vendedor/productos/nuevo">Nuevo Producto</Link></li>
                </ul>
              </li>
            )}
            
            {/* Menú para administradores */}
            {hasRole('admin') && (
              <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                  Admin
                </a>
                <ul className="dropdown-menu">
                  <li><Link className="dropdown-item" to="/admin">Dashboard</Link></li>
                  <li><Link className="dropdown-item" to="/admin/productos">Productos</Link></li>
                  <li><Link className="dropdown-item" to="/admin/ordenes">Órdenes</Link></li>
                  <li><Link className="dropdown-item" to="/admin/usuarios">Usuarios</Link></li>
                </ul>
              </li>
            )}
          </ul>
          
          <ul className="navbar-nav">
            {isAuthenticated ? (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/carrito">
                    <i className="bi bi-cart"></i> Carrito
                    {cartItemCount > 0 && (
                      <span className="badge bg-danger ms-1">{cartItemCount}</span>
                    )}
                  </Link>
                </li>
                <li className="nav-item dropdown">
                  <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                    {user.name || 'Usuario'}
                  </a>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li><Link className="dropdown-item" to="/cuenta">Mi Cuenta</Link></li>
                    <li><Link className="dropdown-item" to="/cuenta/ordenes">Mis Órdenes</Link></li>
                    <li><hr className="dropdown-divider" /></li>
                    <li><button className="dropdown-item" onClick={logout}>Cerrar Sesión</button></li>
                  </ul>
                </li>
              </>
            ) : (
              <li className="nav-item">
                <Link className="nav-link" to="/login">Iniciar Sesión</Link>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}