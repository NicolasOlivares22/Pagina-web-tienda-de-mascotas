import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

// Formateador de moneda para CLP
const CLP = new Intl.NumberFormat('es-CL', { 
  style: 'currency', 
  currency: 'CLP',
  maximumFractionDigits: 0 
});

export default function ProductCard({ product }) {
  const { addToCart, loading } = useCart();
  
  // Manejar la adición al carrito
  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (product.stock <= 0) return;
    
    addToCart(product.id, 1);
  };
  
  // Obtener la primera imagen o usar una imagen por defecto
  const imageUrl = product.images && product.images.length > 0 
    ? product.images[0] 
    : 'https://via.placeholder.com/300x300?text=Sin+Imagen';
  
  return (
    <div className="card h-100 shadow-sm">
      {/* Imagen del producto */}
      <Link to={`/producto/${product.id}`} className="text-decoration-none">
        <img 
          src={imageUrl} 
          className="card-img-top" 
          alt={product.name}
          style={{ height: '200px', objectFit: 'cover' }}
        />
      </Link>
      
      {/* Cuerpo de la tarjeta */}
      <div className="card-body d-flex flex-column">
        {/* Categoría y tipo de mascota */}
        <div className="d-flex justify-content-between mb-2">
          <span className="badge bg-primary">{product.category}</span>
          {product.pet_type && (
            <span className="badge bg-secondary">
              {product.pet_type.charAt(0).toUpperCase() + product.pet_type.slice(1)}
            </span>
          )}
        </div>
        
        {/* Nombre del producto */}
        <Link to={`/producto/${product.id}`} className="text-decoration-none">
          <h5 className="card-title">{product.name}</h5>
        </Link>
        
        {/* Marca */}
        <p className="card-text text-muted mb-1">
          {product.brand}
        </p>
        
        {/* Descripción corta */}
        <p className="card-text small mb-3">
          {product.description?.substring(0, 80)}
          {product.description?.length > 80 ? '...' : ''}
        </p>
        
        {/* Precio y stock */}
        <div className="mt-auto">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <span className="fs-5 fw-bold text-primary">
              {CLP.format(product.price)}
            </span>
            <span className={`badge ${product.stock > 0 ? 'bg-success' : 'bg-danger'}`}>
              {product.stock > 0 ? `Stock: ${product.stock}` : 'Sin stock'}
            </span>
          </div>
          
          {/* Botón de agregar al carrito */}
          <button 
            className="btn btn-primary w-100" 
            onClick={handleAddToCart}
            disabled={product.stock <= 0 || loading}
          >
            {loading ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Agregando...
              </>
            ) : (
              <>
                <i className="bi bi-cart-plus me-2"></i>
                Agregar al carrito
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}