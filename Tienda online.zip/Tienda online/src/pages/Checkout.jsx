import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

// Formateador de moneda para CLP
const CLP = new Intl.NumberFormat('es-CL', { 
  style: 'currency', 
  currency: 'CLP',
  maximumFractionDigits: 0 
});

export default function Checkout() {
  const navigate = useNavigate();
  const { token, user } = useAuth();
  const { cart, cartTotal, clearCart } = useCart();
  
  // Estados para el formulario y proceso de checkout
  const [formData, setFormData] = useState({
    address: '',
    city: '',
    state: '',
    zipCode: '',
    phone: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState(null);
  
  // Manejar cambios en el formulario
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Validar el formulario
  const validateForm = () => {
    const { address, city, state, zipCode, phone } = formData;
    
    if (!address.trim()) {
      setError('La dirección es obligatoria');
      return false;
    }
    
    if (!city.trim()) {
      setError('La ciudad es obligatoria');
      return false;
    }
    
    if (!state.trim()) {
      setError('La región es obligatoria');
      return false;
    }
    
    if (!zipCode.trim()) {
      setError('El código postal es obligatorio');
      return false;
    }
    
    if (!phone.trim()) {
      setError('El teléfono es obligatorio');
      return false;
    }
    
    return true;
  };
  
  // Manejar el envío del formulario
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validar formulario
    if (!validateForm()) return;
    
    // Validar que haya productos en el carrito
    if (!cart || !cart.items || cart.items.length === 0) {
      setError('No hay productos en el carrito');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Preparar datos para el checkout
      const shippingAddress = {
        address: formData.address,
        city: formData.city,
        state: formData.state,
        zip_code: formData.zipCode,
        phone: formData.phone
      };
      
      // Llamar a la API para crear la orden
      const response = await axios.post(
        `${import.meta.env.VITE_XANO_STORE_BASE}/order/checkout`,
        { shipping_address: shippingAddress },
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      // Procesar respuesta exitosa
      setOrderComplete(true);
      setOrderId(response.data.id);
      
      // Limpiar el carrito
      clearCart();
    } catch (err) {
      console.error('Error creating order:', err);
      setError(
        err.response?.data?.message || 
        'No se pudo completar la orden. Por favor, intenta de nuevo más tarde.'
      );
    } finally {
      setLoading(false);
    }
  };
  
  // Renderizar el resumen de la orden
  const renderOrderSummary = () => (
    <div className="card shadow-sm mb-4">
      <div className="card-header bg-primary text-white">
        <h5 className="mb-0">Resumen del pedido</h5>
      </div>
      <div className="card-body">
        <div className="mb-3">
          {cart.items.map((item) => (
            <div key={item.id} className="d-flex justify-content-between mb-2">
              <div>
                <span className="fw-bold">{item.quantity}x</span> {item.product.name}
              </div>
              <span>{CLP.format(item.product.price * item.quantity)}</span>
            </div>
          ))}
        </div>
        <hr />
        <div className="d-flex justify-content-between mb-3 fw-bold">
          <span>Total:</span>
          <span className="fs-5">{CLP.format(cartTotal)}</span>
        </div>
      </div>
    </div>
  );
  
  // Renderizar el formulario de checkout
  const renderCheckoutForm = () => (
    <form onSubmit={handleSubmit}>
      <div className="card shadow-sm">
        <div className="card-header">
          <h5 className="mb-0">Información de envío</h5>
        </div>
        <div className="card-body">
          {error && (
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
          )}
          
          <div className="mb-3">
            <label htmlFor="address" className="form-label">Dirección *</label>
            <input
              type="text"
              className="form-control"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="row mb-3">
            <div className="col-md-6">
              <label htmlFor="city" className="form-label">Ciudad *</label>
              <input
                type="text"
                className="form-control"
                id="city"
                name="city"
                value={formData.city}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-6">
              <label htmlFor="state" className="form-label">Región *</label>
              <input
                type="text"
                className="form-control"
                id="state"
                name="state"
                value={formData.state}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          
          <div className="row mb-3">
            <div className="col-md-6">
              <label htmlFor="zipCode" className="form-label">Código Postal *</label>
              <input
                type="text"
                className="form-control"
                id="zipCode"
                name="zipCode"
                value={formData.zipCode}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-6">
              <label htmlFor="phone" className="form-label">Teléfono *</label>
              <input
                type="tel"
                className="form-control"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          
          <div className="d-grid gap-2">
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Procesando...
                </>
              ) : (
                'Completar compra'
              )}
            </button>
            <button 
              type="button" 
              className="btn btn-outline-secondary"
              onClick={() => navigate('/carrito')}
              disabled={loading}
            >
              Volver al carrito
            </button>
          </div>
        </div>
      </div>
    </form>
  );
  
  // Renderizar la confirmación de la orden
  const renderOrderConfirmation = () => (
    <div className="card shadow-sm">
      <div className="card-body text-center">
        <div className="mb-4">
          <i className="bi bi-check-circle text-success" style={{ fontSize: '4rem' }}></i>
        </div>
        <h3 className="mb-3">¡Gracias por tu compra!</h3>
        <p className="mb-3">
          Tu orden #{orderId} ha sido procesada correctamente.
        </p>
        <p className="mb-4">
          Hemos enviado un correo electrónico a <strong>{user?.email}</strong> con los detalles de tu compra.
        </p>
        <div className="d-grid gap-2">
          <button 
            className="btn btn-primary"
            onClick={() => navigate('/cuenta/ordenes')}
          >
            Ver mis órdenes
          </button>
          <button 
            className="btn btn-outline-primary"
            onClick={() => navigate('/productos')}
          >
            Seguir comprando
          </button>
        </div>
      </div>
    </div>
  );
  
  // Verificar si hay productos en el carrito
  if (!cart || !cart.items || cart.items.length === 0) {
    if (!orderComplete) {
      return (
        <div className="container my-5">
          <div className="alert alert-warning" role="alert">
            No hay productos en el carrito para realizar el checkout.
          </div>
          <button 
            className="btn btn-primary" 
            onClick={() => navigate('/productos')}
          >
            Explorar productos
          </button>
        </div>
      );
    }
  }
  
  return (
    <div className="container my-4">
      <h1 className="mb-4">{orderComplete ? 'Orden completada' : 'Checkout'}</h1>
      
      <div className="row">
        {orderComplete ? (
          <div className="col-lg-8 mx-auto">
            {renderOrderConfirmation()}
          </div>
        ) : (
          <>
            <div className="col-lg-8 mb-4">
              {renderCheckoutForm()}
            </div>
            <div className="col-lg-4">
              {renderOrderSummary()}
            </div>
          </>
        )}
      </div>
    </div>
  );
}