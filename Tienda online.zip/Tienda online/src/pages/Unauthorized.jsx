import React from 'react'
import { Container, Alert, Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'

function Unauthorized() {
  return (
    <Container className="py-5 text-center">
      <Alert variant="warning" className="shadow-sm">
        <Alert.Heading>Acceso No Autorizado</Alert.Heading>
        <p>
          No tienes permisos para acceder a esta sección.
        </p>
        <hr />
        <div className="d-flex justify-content-center">
          <Link to="/">
            <Button variant="outline-primary">
              Volver al Inicio
            </Button>
          </Link>
        </div>
      </Alert>
    </Container>
  )
}

export default Unauthorized