import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Container, Card, Row, Col, Table, Badge, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE;

function AdminOrderDetail() {
  const { orderId } = useParams();
  const { makeAuthHeader, token } = useAuth();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusUpdating, setStatusUpdating] = useState(false);

  useEffect(() => {
    fetchOrderDetails();
  }, [orderId]);

  const fetchOrderDetails = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${STORE_BASE}/admin/orders/${orderId}`, {
        headers: makeAuthHeader(token)
      });
      setOrder(data);
      setError(null);
    } catch (err) {
      console.error('Error al cargar detalles del pedido:', err);
      setError('Error al cargar los detalles del pedido. Por favor, intenta de nuevo más tarde.');
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (newStatus) => {
    setStatusUpdating(true);
    try {
      await axios.put(`${STORE_BASE}/admin/orders/${orderId}/status`, 
        { status: newStatus },
        { headers: makeAuthHeader(token) }
      );
      
      // Actualizar el estado local
      setOrder(prev => ({
        ...prev,
        status: newStatus
      }));
      
    } catch (err) {
      console.error('Error al actualizar estado del pedido:', err);
      setError('Error al actualizar el estado del pedido. Por favor, intenta de nuevo más tarde.');
    } finally {
      setStatusUpdating(false);
    }
  };

  const getStatusBadge = (status) => {
    let variant = 'secondary';
    let text = status;
    
    switch (status) {
      case 'pending':
        variant = 'warning';
        text = 'Pendiente';
        break;
      case 'processing':
        variant = 'info';
        text = 'En proceso';
        break;
      case 'completed':
        variant = 'success';
        text = 'Completado';
        break;
      case 'cancelled':
        variant = 'danger';
        text = 'Cancelado';
        break;
    }
    
    return <Badge bg={variant}>{text}</Badge>;
  };

  if (loading) {
    return (
      <Container>
        <h1 className="mb-4">Detalles del Pedido #{orderId}</h1>
        <p>Cargando detalles del pedido...</p>
      </Container>
    );
  }

  if (error) {
    return (
      <Container>
        <h1 className="mb-4">Detalles del Pedido #{orderId}</h1>
        <Alert variant="danger">{error}</Alert>
        <Button as={Link} to="/admin/ordenes" variant="secondary">
          Volver a la lista de pedidos
        </Button>
      </Container>
    );
  }

  if (!order) {
    return (
      <Container>
        <h1 className="mb-4">Detalles del Pedido #{orderId}</h1>
        <Alert variant="warning">No se encontró el pedido solicitado.</Alert>
        <Button as={Link} to="/admin/ordenes" variant="secondary">
          Volver a la lista de pedidos
        </Button>
      </Container>
    );
  }

  return (
    <Container>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>Detalles del Pedido #{orderId}</h1>
        <Button as={Link} to="/admin/ordenes" variant="outline-secondary">
          Volver a la lista de pedidos
        </Button>
      </div>

      <Row className="mb-4">
        <Col md={6}>
          <Card className="h-100">
            <Card.Header>Información del Pedido</Card.Header>
            <Card.Body>
              <Row className="mb-2">
                <Col xs={4} className="fw-bold">Estado:</Col>
                <Col xs={8}>{getStatusBadge(order.status)}</Col>
              </Row>
              <Row className="mb-2">
                <Col xs={4} className="fw-bold">Fecha:</Col>
                <Col xs={8}>{new Date(order.created_at).toLocaleString()}</Col>
              </Row>
              <Row className="mb-2">
                <Col xs={4} className="fw-bold">Total:</Col>
                <Col xs={8}>${order.total.toFixed(2)}</Col>
              </Row>
              <Row className="mb-2">
                <Col xs={4} className="fw-bold">Método de pago:</Col>
                <Col xs={8}>{order.payment_method || 'No especificado'}</Col>
              </Row>
            </Card.Body>
            <Card.Footer>
              <div className="d-flex gap-2">
                <Button 
                  variant="success" 
                  size="sm"
                  disabled={statusUpdating || order.status === 'completed'}
                  onClick={() => updateOrderStatus('completed')}
                >
                  Marcar como Completado
                </Button>
                <Button 
                  variant="warning" 
                  size="sm"
                  disabled={statusUpdating || order.status === 'processing'}
                  onClick={() => updateOrderStatus('processing')}
                >
                  Marcar como En Proceso
                </Button>
                <Button 
                  variant="danger" 
                  size="sm"
                  disabled={statusUpdating || order.status === 'cancelled'}
                  onClick={() => updateOrderStatus('cancelled')}
                >
                  Cancelar Pedido
                </Button>
              </div>
            </Card.Footer>
          </Card>
        </Col>
        
        <Col md={6}>
          <Card className="h-100">
            <Card.Header>Información del Cliente</Card.Header>
            <Card.Body>
              {order.user ? (
                <>
                  <Row className="mb-2">
                    <Col xs={4} className="fw-bold">Nombre:</Col>
                    <Col xs={8}>{order.user.name}</Col>
                  </Row>
                  <Row className="mb-2">
                    <Col xs={4} className="fw-bold">Email:</Col>
                    <Col xs={8}>{order.user.email}</Col>
                  </Row>
                  <Row className="mb-2">
                    <Col xs={4} className="fw-bold">Teléfono:</Col>
                    <Col xs={8}>{order.user.phone || 'No especificado'}</Col>
                  </Row>
                </>
              ) : (
                <p>Información de usuario no disponible</p>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Card className="mb-4">
        <Card.Header>Dirección de Envío</Card.Header>
        <Card.Body>
          {order.shipping_address ? (
            <address>
              {order.shipping_address.street}, {order.shipping_address.city}<br />
              {order.shipping_address.state}, {order.shipping_address.country} {order.shipping_address.zip}
            </address>
          ) : (
            <p>No hay información de dirección disponible</p>
          )}
        </Card.Body>
      </Card>

      <Card>
        <Card.Header>Productos</Card.Header>
        <Card.Body>
          <div className="table-responsive">
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Precio</th>
                  <th>Cantidad</th>
                  <th>Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {order.items && order.items.map((item, index) => (
                  <tr key={index}>
                    <td>
                      <div className="d-flex align-items-center">
                        {item.product.image && (
                          <img 
                            src={item.product.image} 
                            alt={item.product.name} 
                            style={{ width: '50px', height: '50px', objectFit: 'cover', marginRight: '10px' }}
                          />
                        )}
                        <div>
                          <div>{item.product.name}</div>
                          <small className="text-muted">SKU: {item.product.sku || 'N/A'}</small>
                        </div>
                      </div>
                    </td>
                    <td>${item.price.toFixed(2)}</td>
                    <td>{item.quantity}</td>
                    <td>${(item.price * item.quantity).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan="3" className="text-end fw-bold">Subtotal:</td>
                  <td>${order.subtotal ? order.subtotal.toFixed(2) : '0.00'}</td>
                </tr>
                {order.shipping_cost > 0 && (
                  <tr>
                    <td colSpan="3" className="text-end fw-bold">Envío:</td>
                    <td>${order.shipping_cost.toFixed(2)}</td>
                  </tr>
                )}
                {order.tax > 0 && (
                  <tr>
                    <td colSpan="3" className="text-end fw-bold">Impuestos:</td>
                    <td>${order.tax.toFixed(2)}</td>
                  </tr>
                )}
                {order.discount > 0 && (
                  <tr>
                    <td colSpan="3" className="text-end fw-bold">Descuento:</td>
                    <td>-${order.discount.toFixed(2)}</td>
                  </tr>
                )}
                <tr>
                  <td colSpan="3" className="text-end fw-bold">Total:</td>
                  <td className="fw-bold">${order.total.toFixed(2)}</td>
                </tr>
              </tfoot>
            </Table>
          </div>
        </Card.Body>
      </Card>
    </Container>
  );
}

export default AdminOrderDetail;