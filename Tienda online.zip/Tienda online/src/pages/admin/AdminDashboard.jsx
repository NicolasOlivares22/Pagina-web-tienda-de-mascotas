import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE;

function AdminDashboard() {
  const { makeAuthHeader, token } = useAuth();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProducts: 0,
    totalOrders: 0,
    recentOrders: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        const [usersRes, productsRes, ordersRes, recentOrdersRes] = await Promise.all([
          axios.get(`${STORE_BASE}/admin/users/count`, { headers: makeAuthHeader(token) }),
          axios.get(`${STORE_BASE}/admin/products/count`, { headers: makeAuthHeader(token) }),
          axios.get(`${STORE_BASE}/admin/orders/count`, { headers: makeAuthHeader(token) }),
          axios.get(`${STORE_BASE}/admin/orders/recent`, { headers: makeAuthHeader(token) })
        ]);

        setStats({
          totalUsers: usersRes.data.count || 0,
          totalProducts: productsRes.data.count || 0,
          totalOrders: ordersRes.data.count || 0,
          recentOrders: recentOrdersRes.data.orders || []
        });
        setError(null);
      } catch (err) {
        console.error('Error al cargar datos del dashboard:', err);
        setError('Error al cargar los datos del dashboard. Por favor, intenta de nuevo más tarde.');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [token, makeAuthHeader]);

  if (loading) {
    return (
      <Container>
        <h1 className="mb-4">Dashboard de Administrador</h1>
        <p>Cargando datos...</p>
      </Container>
    );
  }

  if (error) {
    return (
      <Container>
        <h1 className="mb-4">Dashboard de Administrador</h1>
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container>
      <h1 className="mb-4">Dashboard de Administrador</h1>
      
      <Row className="mb-4">
        <Col md={4}>
          <Card className="mb-3">
            <Card.Body>
              <Card.Title>Usuarios</Card.Title>
              <Card.Text className="display-4">{stats.totalUsers}</Card.Text>
              <Link to="/admin/usuarios" className="btn btn-primary">Ver Usuarios</Link>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4}>
          <Card className="mb-3">
            <Card.Body>
              <Card.Title>Productos</Card.Title>
              <Card.Text className="display-4">{stats.totalProducts}</Card.Text>
              <Link to="/admin/productos" className="btn btn-primary">Ver Productos</Link>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4}>
          <Card className="mb-3">
            <Card.Body>
              <Card.Title>Pedidos</Card.Title>
              <Card.Text className="display-4">{stats.totalOrders}</Card.Text>
              <Link to="/admin/ordenes" className="btn btn-primary">Ver Pedidos</Link>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      <h2 className="mb-3">Pedidos Recientes</h2>
      {stats.recentOrders.length > 0 ? (
        <div className="table-responsive">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {stats.recentOrders.map(order => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.user?.name || 'Usuario desconocido'}</td>
                  <td>{new Date(order.created_at).toLocaleDateString()}</td>
                  <td>${order.total.toFixed(2)}</td>
                  <td>
                    <span className={`badge bg-${
                      order.status === 'completed' ? 'success' : 
                      order.status === 'processing' ? 'warning' : 
                      order.status === 'cancelled' ? 'danger' : 'secondary'
                    }`}>
                      {order.status === 'completed' ? 'Completado' : 
                       order.status === 'processing' ? 'En proceso' : 
                       order.status === 'cancelled' ? 'Cancelado' : order.status}
                    </span>
                  </td>
                  <td>
                    <Link to={`/admin/ordenes/${order.id}`} className="btn btn-sm btn-info">
                      Ver detalles
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <Alert variant="info">No hay pedidos recientes</Alert>
      )}
    </Container>
  );
}

export default AdminDashboard;