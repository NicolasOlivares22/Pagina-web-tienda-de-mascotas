import { useState, useEffect } from 'react';
import { Container, Table, Button, Form, Modal, Alert, Badge } from 'react-bootstrap';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE;

function AdminUsers() {
  const { makeAuthHeader, token } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'customer',
    password: '',
    active: true
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${STORE_BASE}/admin/users`, {
        headers: makeAuthHeader(token)
      });
      setUsers(data.users || []);
      setError(null);
    } catch (err) {
      console.error('Error al cargar usuarios:', err);
      setError('Error al cargar los usuarios. Por favor, intenta de nuevo más tarde.');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (user = null) => {
    if (user) {
      setCurrentUser(user);
      setFormData({
        name: user.name || '',
        email: user.email || '',
        role: user.role || 'customer',
        password: '',
        active: user.active !== false
      });
    } else {
      setCurrentUser(null);
      setFormData({
        name: '',
        email: '',
        role: 'customer',
        password: '',
        active: true
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setCurrentUser(null);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (currentUser) {
        // Actualizar usuario existente
        const updateData = { ...formData };
        if (!updateData.password) delete updateData.password;
        
        await axios.put(
          `${STORE_BASE}/admin/users/${currentUser.id}`,
          updateData,
          { headers: makeAuthHeader(token) }
        );
      } else {
        // Crear nuevo usuario
        await axios.post(
          `${STORE_BASE}/admin/users`,
          formData,
          { headers: makeAuthHeader(token) }
        );
      }
      
      // Recargar la lista de usuarios
      fetchUsers();
      handleCloseModal();
    } catch (err) {
      console.error('Error al guardar usuario:', err);
      setError('Error al guardar los cambios. Por favor, intenta de nuevo.');
    }
  };

  const handleToggleActive = async (userId, currentActive) => {
    try {
      await axios.put(
        `${STORE_BASE}/admin/users/${userId}`,
        { active: !currentActive },
        { headers: makeAuthHeader(token) }
      );
      
      // Actualizar el estado local
      setUsers(users.map(user => 
        user.id === userId ? { ...user, active: !currentActive } : user
      ));
    } catch (err) {
      console.error('Error al cambiar estado del usuario:', err);
      setError('Error al actualizar el estado del usuario. Por favor, intenta de nuevo.');
    }
  };

  if (loading && users.length === 0) {
    return (
      <Container>
        <h1 className="mb-4">Administrar Usuarios</h1>
        <p>Cargando usuarios...</p>
      </Container>
    );
  }

  return (
    <Container>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>Administrar Usuarios</h1>
        <Button variant="primary" onClick={() => handleOpenModal()}>
          Nuevo Usuario
        </Button>
      </div>
      
      {error && <Alert variant="danger">{error}</Alert>}
      
      {users.length === 0 ? (
        <Alert variant="info">No hay usuarios disponibles</Alert>
      ) : (
        <div className="table-responsive">
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>
                    <Badge bg={user.role === 'admin' ? 'danger' : 'info'}>
                      {user.role === 'admin' ? 'Administrador' : 'Cliente'}
                    </Badge>
                  </td>
                  <td>
                    <Badge bg={user.active !== false ? 'success' : 'secondary'}>
                      {user.active !== false ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </td>
                  <td>
                    <div className="d-flex gap-2">
                      <Button 
                        variant="outline-primary" 
                        size="sm"
                        onClick={() => handleOpenModal(user)}
                      >
                        Editar
                      </Button>
                      <Button 
                        variant={user.active !== false ? "outline-secondary" : "outline-success"} 
                        size="sm"
                        onClick={() => handleToggleActive(user.id, user.active !== false)}
                      >
                        {user.active !== false ? 'Desactivar' : 'Activar'}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
      
      {/* Modal para crear/editar usuario */}
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>{currentUser ? 'Editar Usuario' : 'Nuevo Usuario'}</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>Nombre</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Contraseña {currentUser && '(dejar en blanco para mantener la actual)'}</Form.Label>
              <Form.Control
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                required={!currentUser}
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Rol</Form.Label>
              <Form.Select
                name="role"
                value={formData.role}
                onChange={handleInputChange}
              >
                <option value="customer">Cliente</option>
                <option value="admin">Administrador</option>
              </Form.Select>
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Check
                type="checkbox"
                label="Usuario activo"
                name="active"
                checked={formData.active}
                onChange={handleInputChange}
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Cancelar
            </Button>
            <Button variant="primary" type="submit">
              Guardar
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </Container>
  );
}

export default AdminUsers;