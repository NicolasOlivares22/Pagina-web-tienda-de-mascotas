import { useState, useEffect } from 'react';
import { Container, Table, Badge, Button, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';

const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE;

function AdminOrders() {
  const { makeAuthHeader, token } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${STORE_BASE}/admin/orders`, {
        headers: makeAuthHeader(token)
      });
      setOrders(data.orders || []);
      setError(null);
    } catch (err) {
      console.error('Error al cargar pedidos:', err);
      setError('Error al cargar los pedidos. Por favor, intenta de nuevo más tarde.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    let variant = 'secondary';
    let text = status;
    
    switch (status) {
      case 'pending':
        variant = 'warning';
        text = 'Pendiente';
        break;
      case 'processing':
        variant = 'info';
        text = 'En proceso';
        break;
      case 'completed':
        variant = 'success';
        text = 'Completado';
        break;
      case 'cancelled':
        variant = 'danger';
        text = 'Cancelado';
        break;
    }
    
    return <Badge bg={variant}>{text}</Badge>;
  };

  if (loading && orders.length === 0) {
    return (
      <Container>
        <h1 className="mb-4">Administrar Pedidos</h1>
        <p>Cargando pedidos...</p>
      </Container>
    );
  }

  return (
    <Container>
      <h1 className="mb-4">Administrar Pedidos</h1>
      
      {error && <Alert variant="danger">{error}</Alert>}
      
      {orders.length === 0 ? (
        <Alert variant="info">No hay pedidos disponibles</Alert>
      ) : (
        <div className="table-responsive">
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.user?.name || 'Usuario desconocido'}</td>
                  <td>{new Date(order.created_at).toLocaleDateString()}</td>
                  <td>${order.total.toFixed(2)}</td>
                  <td>{getStatusBadge(order.status)}</td>
                  <td>
                    <Link to={`/admin/ordenes/${order.id}`} className="btn btn-sm btn-primary">
                      Ver detalles
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
    </Container>
  );
}

export default AdminOrders;