import React from 'react'
import { useAuth } from '../context/AuthContext'
import { Container, Row, Col, Card } from 'react-bootstrap'

function Account() {
  const { user } = useAuth()

  return (
    <Container>
      <h1 className="mb-4">Mi Cuenta</h1>
      <Row>
        <Col md={8}>
          <Card className="shadow-sm mb-4">
            <Card.Body>
              <Card.Title>Información Personal</Card.Title>
              <hr />
              <Row className="mb-3">
                <Col sm={4} className="text-muted">Nombre:</Col>
                <Col sm={8}>{user?.name || 'No disponible'}</Col>
              </Row>
              <Row className="mb-3">
                <Col sm={4} className="text-muted">Email:</Col>
                <Col sm={8}>{user?.email || 'No disponible'}</Col>
              </Row>
              <Row className="mb-3">
                <Col sm={4} className="text-muted">Rol:</Col>
                <Col sm={8}>{user?.role || 'Cliente'}</Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="shadow-sm">
            <Card.Body>
              <Card.Title>Acciones</Card.Title>
              <hr />
              <div className="d-grid gap-2">
                <a href="/orders" className="btn btn-outline-primary">Mis Pedidos</a>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default Account