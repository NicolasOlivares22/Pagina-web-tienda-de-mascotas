import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

// Formateador de moneda para CLP
const CLP = new Intl.NumberFormat('es-CL', { 
  style: 'currency', 
  currency: 'CLP',
  maximumFractionDigits: 0 
});

export default function Cart() {
  const navigate = useNavigate();
  const { isAuthenticated, isBlocked } = useAuth();
  const { 
    cart, 
    loading, 
    updateCartItem, 
    removeCartItem, 
    cartTotal 
  } = useCart();
  
  // Estado para controlar las cantidades en edición
  const [quantities, setQuantities] = useState({});
  
  // Manejar cambio de cantidad
  const handleQuantityChange = (itemId, productId, stock, value) => {
    const newValue = parseInt(value);
    
    // Validar que la cantidad sea válida
    if (isNaN(newValue) || newValue < 1) {
      setQuantities({ ...quantities, [itemId]: 1 });
    } else if (newValue > stock) {
      setQuantities({ ...quantities, [itemId]: stock });
    } else {
      setQuantities({ ...quantities, [itemId]: newValue });
    }
  };
  
  // Actualizar cantidad en el carrito
  const handleUpdateQuantity = (itemId, productId, quantity) => {
    updateCartItem(itemId, quantity);
    // Limpiar el estado local después de actualizar
    const newQuantities = { ...quantities };
    delete newQuantities[itemId];
    setQuantities(newQuantities);
  };
  
  // Iniciar edición de cantidad
  const startEditing = (itemId, currentQuantity) => {
    setQuantities({ ...quantities, [itemId]: currentQuantity });
  };
  
  // Cancelar edición de cantidad
  const cancelEditing = (itemId) => {
    const newQuantities = { ...quantities };
    delete newQuantities[itemId];
    setQuantities(newQuantities);
  };
  
  // Verificar si un item está en modo edición
  const isEditing = (itemId) => {
    return itemId in quantities;
  };
  
  // Renderizar el carrito vacío
  const renderEmptyCart = () => (
    <div className="text-center my-5">
      <i className="bi bi-cart-x fs-1 text-muted mb-3"></i>
      <h3>Tu carrito está vacío</h3>
      <p className="text-muted mb-4">
        Parece que aún no has agregado productos a tu carrito.
      </p>
      <Link to="/productos" className="btn btn-primary">
        Explorar productos
      </Link>
    </div>
  );
  
  // Renderizar la tabla de productos en el carrito
  const renderCartItems = () => (
    <div className="table-responsive">
      <table className="table align-middle">
        <thead>
          <tr>
            <th scope="col">Producto</th>
            <th scope="col" className="text-center">Precio</th>
            <th scope="col" className="text-center">Cantidad</th>
            <th scope="col" className="text-center">Subtotal</th>
            <th scope="col" className="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {cart.items.map((item) => (
            <tr key={item.id}>
              {/* Producto */}
              <td>
                <div className="d-flex align-items-center">
                  <img 
                    src={item.product.images?.[0] || 'https://via.placeholder.com/80x80?text=Sin+Imagen'} 
                    alt={item.product.name}
                    className="img-thumbnail me-3"
                    style={{ width: '80px', height: '80px', objectFit: 'cover' }}
                  />
                  <div>
                    <h6 className="mb-1">
                      <Link to={`/producto/${item.product.id}`} className="text-decoration-none">
                        {item.product.name}
                      </Link>
                    </h6>
                    <small className="text-muted d-block">
                      {item.product.brand}
                    </small>
                    {item.product.stock < 5 && (
                      <small className="text-danger">
                        ¡Solo quedan {item.product.stock} unidades!
                      </small>
                    )}
                  </div>
                </div>
              </td>
              
              {/* Precio unitario */}
              <td className="text-center">
                {CLP.format(item.product.price)}
              </td>
              
              {/* Cantidad */}
              <td className="text-center" style={{ minWidth: '150px' }}>
                {isEditing(item.id) ? (
                  <div className="d-flex align-items-center justify-content-center gap-2">
                    <input
                      type="number"
                      className="form-control form-control-sm text-center"
                      style={{ width: '70px' }}
                      value={quantities[item.id]}
                      onChange={(e) => handleQuantityChange(
                        item.id, 
                        item.product.id, 
                        item.product.stock, 
                        e.target.value
                      )}
                      min="1"
                      max={item.product.stock}
                    />
                    <div className="btn-group btn-group-sm">
                      <button 
                        className="btn btn-success"
                        onClick={() => handleUpdateQuantity(
                          item.id, 
                          item.product.id, 
                          quantities[item.id]
                        )}
                        disabled={loading}
                      >
                        <i className="bi bi-check"></i>
                      </button>
                      <button 
                        className="btn btn-secondary"
                        onClick={() => cancelEditing(item.id)}
                        disabled={loading}
                      >
                        <i className="bi bi-x"></i>
                      </button>
                    </div>
                  </div>
                ) : (
                  <span>{item.quantity}</span>
                )}
              </td>
              
              {/* Subtotal */}
              <td className="text-center fw-bold">
                {CLP.format(item.product.price * item.quantity)}
              </td>
              
              {/* Acciones */}
              <td className="text-center">
                <div className="btn-group btn-group-sm">
                  {!isEditing(item.id) && (
                    <button 
                      className="btn btn-outline-primary"
                      onClick={() => startEditing(item.id, item.quantity)}
                      disabled={loading}
                    >
                      <i className="bi bi-pencil"></i>
                    </button>
                  )}
                  <button 
                    className="btn btn-outline-danger"
                    onClick={() => removeCartItem(item.id)}
                    disabled={loading}
                  >
                    <i className="bi bi-trash"></i>
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
  // Renderizar el resumen del carrito
  const renderCartSummary = () => (
    <div className="card shadow-sm">
      <div className="card-header bg-primary text-white">
        <h5 className="mb-0">Resumen del pedido</h5>
      </div>
      <div className="card-body">
        <div className="d-flex justify-content-between mb-2">
          <span>Subtotal:</span>
          <span>{CLP.format(cartTotal)}</span>
        </div>
        <div className="d-flex justify-content-between mb-3">
          <span>Envío:</span>
          <span>Calculado en checkout</span>
        </div>
        <hr />
        <div className="d-flex justify-content-between mb-3 fw-bold">
          <span>Total:</span>
          <span className="fs-5">{CLP.format(cartTotal)}</span>
        </div>
        <button 
          className="btn btn-primary w-100"
          onClick={() => navigate('/checkout')}
          disabled={loading || isBlocked() || !isAuthenticated()}
        >
          Proceder al checkout
        </button>
        
        {!isAuthenticated() && (
          <div className="alert alert-warning mt-3 mb-0">
            <i className="bi bi-exclamation-triangle me-2"></i>
            Debes <Link to="/login" className="alert-link">iniciar sesión</Link> para completar tu compra.
          </div>
        )}
        
        {isBlocked() && (
          <div className="alert alert-danger mt-3 mb-0">
            <i className="bi bi-x-circle me-2"></i>
            Tu cuenta está bloqueada. No puedes realizar compras.
          </div>
        )}
      </div>
    </div>
  );
  
  if (loading && (!cart || !cart.items)) {
    return (
      <div className="container my-5 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Cargando...</span>
        </div>
        <p className="mt-2">Cargando carrito...</p>
      </div>
    );
  }
  
  return (
    <div className="container my-4">
      <h1 className="mb-4">Carrito de compras</h1>
      
      {(!cart || !cart.items || cart.items.length === 0) ? (
        renderEmptyCart()
      ) : (
        <div className="row">
          <div className="col-lg-8 mb-4">
            {renderCartItems()}
            
            <div className="d-flex justify-content-between mt-3">
              <Link to="/productos" className="btn btn-outline-primary">
                <i className="bi bi-arrow-left me-2"></i>
                Seguir comprando
              </Link>
            </div>
          </div>
          
          <div className="col-lg-4">
            {renderCartSummary()}
          </div>
        </div>
      )}
    </div>
  );
}