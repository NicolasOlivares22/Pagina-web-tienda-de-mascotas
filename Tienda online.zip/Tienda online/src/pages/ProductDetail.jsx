import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

// Formateador de moneda para CLP
const CLP = new Intl.NumberFormat('es-CL', { 
  style: 'currency', 
  currency: 'CLP',
  maximumFractionDigits: 0 
});

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { token } = useAuth();
  const { addToCart, loading: cartLoading } = useCart();
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  
  // Cargar detalles del producto
  useEffect(() => {
    const fetchProductDetail = async () => {
      setLoading(true);
      setError(null);
      
      try {
        // Configurar headers con token si está disponible
        const config = {};
        if (token) {
          config.headers = {
            'Authorization': `Bearer ${token}`
          };
        }
        
        const response = await axios.get(
          `${import.meta.env.VITE_XANO_STORE_BASE}/product/${id}`,
          config
        );
        
        setProduct(response.data);
      } catch (err) {
        console.error('Error fetching product details:', err);
        setError('No se pudo cargar el detalle del producto. Por favor, intenta de nuevo más tarde.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchProductDetail();
  }, [id, token]);
  
  // Manejar cambio de cantidad
  const handleQuantityChange = (e) => {
    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 1) {
      setQuantity(1);
    } else if (product && value > product.stock) {
      setQuantity(product.stock);
    } else {
      setQuantity(value);
    }
  };
  
  // Manejar agregar al carrito
  const handleAddToCart = () => {
    if (product && product.stock > 0 && quantity > 0) {
      addToCart(product.id, quantity);
    }
  };
  
  // Renderizar carrusel de imágenes
  const renderImageCarousel = () => {
    if (!product || !product.images || product.images.length === 0) {
      return (
        <div className="text-center p-5 bg-light">
          <i className="bi bi-image fs-1"></i>
          <p>No hay imágenes disponibles</p>
        </div>
      );
    }
    
    return (
      <div>
        {/* Imagen principal */}
        <div className="mb-3">
          <img 
            src={product.images[activeImage]} 
            className="img-fluid rounded" 
            alt={`${product.name} - Imagen ${activeImage + 1}`}
            style={{ maxHeight: '400px', width: '100%', objectFit: 'contain' }}
          />
        </div>
        
        {/* Miniaturas */}
        {product.images.length > 1 && (
          <div className="d-flex gap-2 overflow-auto pb-2">
            {product.images.map((img, index) => (
              <img 
                key={index}
                src={img} 
                className={`img-thumbnail cursor-pointer ${activeImage === index ? 'border-primary' : ''}`}
                alt={`Miniatura ${index + 1}`}
                style={{ 
                  width: '80px', 
                  height: '80px', 
                  objectFit: 'cover',
                  cursor: 'pointer',
                  opacity: activeImage === index ? 1 : 0.7
                }}
                onClick={() => setActiveImage(index)}
              />
            ))}
          </div>
        )}
      </div>
    );
  };
  
  if (loading) {
    return (
      <div className="container my-5 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Cargando...</span>
        </div>
        <p className="mt-2">Cargando detalles del producto...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="container my-5">
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
        <button 
          className="btn btn-primary" 
          onClick={() => navigate('/productos')}
        >
          Volver a productos
        </button>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container my-5">
        <div className="alert alert-warning" role="alert">
          Producto no encontrado
        </div>
        <button 
          className="btn btn-primary" 
          onClick={() => navigate('/productos')}
        >
          Volver a productos
        </button>
      </div>
    );
  }
  
  return (
    <div className="container my-4">
      {/* Breadcrumb */}
      <nav aria-label="breadcrumb" className="mb-4">
        <ol className="breadcrumb">
          <li className="breadcrumb-item">
            <a href="/" className="text-decoration-none">Inicio</a>
          </li>
          <li className="breadcrumb-item">
            <a href="/productos" className="text-decoration-none">Productos</a>
          </li>
          <li className="breadcrumb-item active" aria-current="page">
            {product.name}
          </li>
        </ol>
      </nav>
      
      <div className="row">
        {/* Imágenes del producto */}
        <div className="col-md-6 mb-4">
          {renderImageCarousel()}
        </div>
        
        {/* Información del producto */}
        <div className="col-md-6">
          <h1 className="mb-2">{product.name}</h1>
          
          <div className="d-flex gap-2 mb-3">
            {product.category && (
              <span className="badge bg-primary">{product.category}</span>
            )}
            {product.pet_type && (
              <span className="badge bg-secondary">
                {product.pet_type.charAt(0).toUpperCase() + product.pet_type.slice(1)}
              </span>
            )}
          </div>
          
          <p className="text-muted mb-3">
            <strong>Marca:</strong> {product.brand || 'No especificada'}
          </p>
          
          <h3 className="text-primary mb-3">
            {CLP.format(product.price)}
          </h3>
          
          <div className="mb-4">
            <span className={`badge ${product.stock > 0 ? 'bg-success' : 'bg-danger'} mb-2`}>
              {product.stock > 0 ? `Stock disponible: ${product.stock}` : 'Sin stock'}
            </span>
            
            {product.stock > 0 && (
              <div className="d-flex align-items-center gap-3 mt-2">
                <label htmlFor="quantity" className="form-label mb-0">Cantidad:</label>
                <input
                  type="number"
                  id="quantity"
                  className="form-control"
                  style={{ width: '80px' }}
                  value={quantity}
                  onChange={handleQuantityChange}
                  min="1"
                  max={product.stock}
                />
              </div>
            )}
          </div>
          
          <button 
            className="btn btn-primary btn-lg w-100 mb-3" 
            onClick={handleAddToCart}
            disabled={product.stock <= 0 || cartLoading}
          >
            {cartLoading ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Agregando al carrito...
              </>
            ) : (
              <>
                <i className="bi bi-cart-plus me-2"></i>
                Agregar al carrito
              </>
            )}
          </button>
          
          <div className="card mt-4">
            <div className="card-header">
              <h5 className="mb-0">Descripción</h5>
            </div>
            <div className="card-body">
              <p className="card-text">{product.description || 'No hay descripción disponible para este producto.'}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}