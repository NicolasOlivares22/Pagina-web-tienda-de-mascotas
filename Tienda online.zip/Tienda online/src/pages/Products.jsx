import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ProductGrid from '../components/ProductGrid';

export default function Products() {
  const { token } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Estados para los filtros
  const [search, setSearch] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [petType, setPetType] = useState(searchParams.get('pet_type') || '');
  const [brand, setBrand] = useState(searchParams.get('brand') || '');
  const [minPrice, setMinPrice] = useState(searchParams.get('min_price') || '');
  const [maxPrice, setMaxPrice] = useState(searchParams.get('max_price') || '');
  const [sort, setSort] = useState(searchParams.get('sort') || 'newest');
  
  // Categorías y tipos de mascotas (en una aplicación real, estos vendrían de la API)
  const categories = ['Alimentos', 'Accesorios', 'Juguetes', 'Higiene', 'Salud'];
  const petTypes = ['perro', 'gato', 'ave', 'pez', 'roedor', 'reptil', 'otro'];
  const brands = ['Royal Canin', 'Purina', 'Pedigree', 'Whiskas', 'Hills', 'Kong', 'Otras'];
  
  // Actualizar los parámetros de búsqueda cuando cambien los filtros
  useEffect(() => {
    const params = {};
    if (search) params.q = search;
    if (category) params.category = category;
    if (petType) params.pet_type = petType;
    if (brand) params.brand = brand;
    if (minPrice) params.min_price = minPrice;
    if (maxPrice) params.max_price = maxPrice;
    if (sort) params.sort = sort;
    
    setSearchParams(params);
  }, [search, category, petType, brand, minPrice, maxPrice, sort, setSearchParams]);
  
  // Manejar el envío del formulario de búsqueda
  const handleSubmit = (e) => {
    e.preventDefault();
  };
  
  // Limpiar todos los filtros
  const clearFilters = () => {
    setSearch('');
    setCategory('');
    setPetType('');
    setBrand('');
    setMinPrice('');
    setMaxPrice('');
    setSort('newest');
    setSearchParams({});
  };
  
  return (
    <div className="container">
      <h1 className="mb-4">Productos</h1>
      
      <div className="row">
        {/* Filtros */}
        <div className="col-md-3 mb-4">
          <div className="card">
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">Filtros</h5>
              <button 
                className="btn btn-sm btn-outline-secondary" 
                onClick={clearFilters}
              >
                Limpiar
              </button>
            </div>
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                {/* Búsqueda */}
                <div className="mb-3">
                  <label htmlFor="search" className="form-label">Buscar</label>
                  <input
                    type="text"
                    className="form-control"
                    id="search"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Nombre o descripción"
                  />
                </div>
                
                {/* Categoría */}
                <div className="mb-3">
                  <label htmlFor="category" className="form-label">Categoría</label>
                  <select
                    className="form-select"
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    <option value="">Todas las categorías</option>
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                
                {/* Tipo de mascota */}
                <div className="mb-3">
                  <label htmlFor="petType" className="form-label">Tipo de mascota</label>
                  <select
                    className="form-select"
                    id="petType"
                    value={petType}
                    onChange={(e) => setPetType(e.target.value)}
                  >
                    <option value="">Todas las mascotas</option>
                    {petTypes.map((type) => (
                      <option key={type} value={type}>
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* Marca */}
                <div className="mb-3">
                  <label htmlFor="brand" className="form-label">Marca</label>
                  <select
                    className="form-select"
                    id="brand"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                  >
                    <option value="">Todas las marcas</option>
                    {brands.map((b) => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>
                
                {/* Rango de precio */}
                <div className="mb-3">
                  <label className="form-label">Rango de precio</label>
                  <div className="d-flex gap-2">
                    <input
                      type="number"
                      className="form-control"
                      placeholder="Min"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value)}
                    />
                    <input
                      type="number"
                      className="form-control"
                      placeholder="Max"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                    />
                  </div>
                </div>
                
                {/* Ordenar por */}
                <div className="mb-3">
                  <label htmlFor="sort" className="form-label">Ordenar por</label>
                  <select
                    className="form-select"
                    id="sort"
                    value={sort}
                    onChange={(e) => setSort(e.target.value)}
                  >
                    <option value="newest">Más recientes</option>
                    <option value="price_asc">Precio: menor a mayor</option>
                    <option value="price_desc">Precio: mayor a menor</option>
                    <option value="name_asc">Nombre: A-Z</option>
                    <option value="name_desc">Nombre: Z-A</option>
                  </select>
                </div>
                
                <button type="submit" className="btn btn-primary w-100">
                  Aplicar filtros
                </button>
              </form>
            </div>
          </div>
        </div>
        
        {/* Lista de productos */}
        <div className="col-md-9">
          <ProductGrid 
            token={token} 
            query={search}
            category={category}
            petType={petType}
            brand={brand}
            minPrice={minPrice}
            maxPrice={maxPrice}
            sort={sort}
          />
        </div>
      </div>
    </div>
  );
}