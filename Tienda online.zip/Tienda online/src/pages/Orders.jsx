import React, { useState, useEffect } from 'react'
import { Container, Table, Badge, Spinner } from 'react-bootstrap'
import { useAuth } from '../context/AuthContext'
import axios from 'axios'

const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE

function Orders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const { token, makeAuthHeader } = useAuth()

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const { data } = await axios.get(`${STORE_BASE}/orders/my_orders`, {
          headers: makeAuthHeader()
        })
        setOrders(data || [])
      } catch (error) {
        console.error('Error al cargar pedidos:', error)
      } finally {
        setLoading(false)
      }
    }

    if (token) {
      fetchOrders()
    }
  }, [token])

  const getStatusBadge = (status) => {
    const statusMap = {
      'pending': { text: 'Pendiente', variant: 'warning' },
      'processing': { text: 'Procesando', variant: 'info' },
      'shipped': { text: 'Enviado', variant: 'primary' },
      'delivered': { text: 'Entregado', variant: 'success' },
      'cancelled': { text: 'Cancelado', variant: 'danger' }
    }
    
    const statusInfo = statusMap[status] || { text: status, variant: 'secondary' }
    
    return <Badge bg={statusInfo.variant}>{statusInfo.text}</Badge>
  }

  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Cargando...</span>
        </Spinner>
      </Container>
    )
  }

  return (
    <Container>
      <h1 className="mb-4">Mis Pedidos</h1>
      
      {orders.length === 0 ? (
        <div className="alert alert-info">
          No tienes pedidos realizados todavía.
        </div>
      ) : (
        <div className="table-responsive">
          <Table striped hover className="shadow-sm">
            <thead>
              <tr>
                <th>Pedido #</th>
                <th>Fecha</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Productos</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{new Date(order.created_at).toLocaleDateString()}</td>
                  <td>${order.total.toFixed(2)}</td>
                  <td>{getStatusBadge(order.status)}</td>
                  <td>{order.items?.length || 0} items</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
    </Container>
  )
}

export default Orders