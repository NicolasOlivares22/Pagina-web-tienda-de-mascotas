import React from 'react'
import { Container, Alert, Button } from 'react-bootstrap'
import { useAuth } from '../context/AuthContext'

function Blocked() {
  const { logout } = useAuth()

  return (
    <Container className="py-5 text-center">
      <Alert variant="danger" className="shadow-sm">
        <Alert.Heading>Cuenta Bloqueada</Alert.Heading>
        <p>
          Tu cuenta ha sido bloqueada por un administrador. 
          Si crees que esto es un error, por favor contacta con soporte.
        </p>
        <hr />
        <div className="d-flex justify-content-center">
          <Button variant="outline-danger" onClick={logout}>
            Cerrar Sesión
          </Button>
        </div>
      </Alert>
    </Container>
  )
}

export default Blocked