import { Link } from 'react-router-dom';
import ProductGrid from '../components/ProductGrid.jsx';
import { useAuth } from '../context/AuthContext';

export default function Home() {
  const { token } = useAuth();
  
  return (
    <div className="container">
      <div className="row align-items-center py-5">
        <div className="col-md-6">
          <h1 className="display-4 fw-bold" style={{color: 'var(--primary-color)'}}>Bienvenido a PetShop Xano</h1>
          <p className="lead">Tu tienda favorita para productos de mascotas</p>
          <p className="mb-4">Encuentra todo lo que necesitas para tus compañeros peludos: alimentos premium, accesorios de calidad, juguetes divertidos y mucho más.</p>
          <div className="d-flex gap-2">
            <Link to="/productos" className="btn btn-primary btn-lg">Ver Productos</Link>
            <Link to="/productos?featured=true" className="btn btn-outline-primary btn-lg">Destacados</Link>
          </div>
        </div>
        <div className="col-md-6">
          <img src="https://placehold.co/600x400?text=PetShop+Xano" alt="PetShop Xano" className="img-fluid rounded-3 shadow" style={{borderRadius: '20px'}} />
        </div>
      </div>
      
      <div className="row mt-5">
        <div className="col-12 text-center mb-4">
          <h2>Categorías Destacadas</h2>
        </div>
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            <img src="https://placehold.co/400x300?text=Perros" className="card-img-top" alt="Perros" />
            <div className="card-body text-center">
              <h5 className="card-title">Perros</h5>
              <Link to="/productos?pet_type=perro" className="btn btn-outline-primary">Ver productos</Link>
            </div>
          </div>
        </div>
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            <img src="https://placehold.co/400x300?text=Gatos" className="card-img-top" alt="Gatos" />
            <div className="card-body text-center">
              <h5 className="card-title">Gatos</h5>
              <Link to="/productos?pet_type=gato" className="btn btn-outline-primary">Ver productos</Link>
            </div>
          </div>
        </div>
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            <img src="https://placehold.co/400x300?text=Otros" className="card-img-top" alt="Otros" />
            <div className="card-body text-center">
              <h5 className="card-title">Otras Mascotas</h5>
              <Link to="/productos?pet_type=otro" className="btn btn-outline-primary">Ver productos</Link>
            </div>
          </div>
        </div>
      </div>
      
      <div className="row mt-5">
        <div className="col-12 text-center mb-4">
          <h2>Productos Destacados</h2>
        </div>
        <div className="col-12">
          <ProductGrid token={token} limit={4} />
          <div className="text-center mt-4">
            <Link to="/productos" className="btn btn-primary">Ver todos los productos</Link>
          </div>
        </div>
      </div>

      {/* Sección de testimonios de clientes */}
      <div className="testimonials-section my-5 p-4">
        <div className="row">
          <div className="col-12 text-center mb-4">
            <h2 className="text-white">Lo que dicen nuestros clientes</h2>
            <p className="text-white-50">Miles de dueños de mascotas confían en nosotros</p>
          </div>
        </div>
        <div className="row">
          <div className="col-md-4 mb-3">
            <div className="testimonial-card">
              <div className="rating">
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
              </div>
              <p className="testimonial-text">"Excelente servicio y productos de calidad. Mi perro adora los juguetes que compré aquí. Definitivamente volveré a comprar."</p>
              <p className="customer-name">María F.</p>
            </div>
          </div>
          <div className="col-md-4 mb-3">
            <div className="testimonial-card">
              <div className="rating">
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
              </div>
              <p className="testimonial-text">"Compré un shampoo para mi perro que sufría de alergias y es muy bueno. Se nota la calidad en todos sus productos."</p>
              <p className="customer-name">Carlos R.</p>
            </div>
          </div>
          <div className="col-md-4 mb-3">
            <div className="testimonial-card">
              <div className="rating">
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
                <i className="bi bi-star-fill"></i>
              </div>
              <p className="testimonial-text">"Excelente tienda, he probado muchos productos y todos son de gran calidad. El envío fue rápido y el servicio al cliente es excepcional."</p>
              <p className="customer-name">Javiera E.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}