// Importamos createContext y useState/useEffect para gestionar el estado global de autenticación
import { createContext, useContext, useEffect, useMemo, useState } from 'react'
// Importamos axios para una de las formas de llamar al API
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

// Leemos las bases de los endpoints desde variables de entorno
const AUTH_BASE = import.meta.env.VITE_XANO_AUTH_BASE // Base para endpoints de autenticación
const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE // Base para endpoints de la tienda/productos
// TTL de respaldo para tokens JWE sin 'exp' legible (por defecto 86400s)
const TOKEN_TTL_SEC = Number(import.meta.env.VITE_XANO_TOKEN_TTL_SEC || '86400')

// Creamos el contexto de autenticación
const AuthContext = createContext(null) // Contexto que compartirá usuario, token y acciones

// Función auxiliar para decodificar un JWT y obtener su payload (incluye 'exp' si existe)
function decodeJwt(token) {
  // Si no hay token, devolvemos null
  if (!token) return null
  try {
    const parts = token.split('.')
    if (parts.length < 2) return null
    // Normalizamos Base64URL y agregamos padding
    let payload = parts[1].replace(/-/g, '+').replace(/_/g, '/')
    const pad = payload.length % 4
    if (pad) payload += '='.repeat(4 - pad)
    const json = atob(payload)
    return JSON.parse(json)
  } catch {
    // Si falla la decodificación, devolvemos null
    return null
  }
}

// Proveedor del contexto que envuelve la aplicación
export function AuthProvider({ children }) {
  // Estado para el token JWT
  const [token, setToken] = useState(() => localStorage.getItem('auth_token') || '') // Inicializamos desde localStorage
  // Estado para el usuario (nombre u otros datos)
  const [user, setUser] = useState(() => {
    // Intentamos leer el usuario del almacenamiento
    const raw = localStorage.getItem('auth_user') // Obtenemos cadena guardada
    return raw ? JSON.parse(raw) : null // Parseamos o null si no existe
  })
  // Estado para el instante de expiración del token en milisegundos
  const [expiresAt, setExpiresAt] = useState(() => {
    // Leemos expiración guardada si existe
    const raw = localStorage.getItem('auth_exp') // Obtenemos cadena de tiempo
    return raw ? Number(raw) : null // Convertimos a número o null
  })
  
  // Estado para indicar si estamos cargando
  const [loading, setLoading] = useState(false)
  
  const navigate = useNavigate()

  // Efecto: cada vez que cambie el token, actualizamos expiración leyendo el JWT o usando TTL
  useEffect(() => {
    // Si no hay token, limpiamos todo y salimos
    if (!token) {
      localStorage.removeItem('auth_token')
      setExpiresAt(null)
      localStorage.removeItem('auth_exp')
      return
    }

    // Persistimos el token
    localStorage.setItem('auth_token', token)

    // Intentamos decodificar (JWT). Si no hay exp, usamos TTL de respaldo
    const payload = decodeJwt(token)
    let expMs = payload?.exp ? payload.exp * 1000 : null
    if (!expMs) expMs = Date.now() + (TOKEN_TTL_SEC * 1000)

    // Guardamos expiración en estado y almacenamiento
    setExpiresAt(expMs)
    localStorage.setItem('auth_exp', String(expMs))
  }, [token])

  // Efecto: persistimos el usuario cada vez que cambie
  useEffect(() => {
    // Si hay usuario, lo guardamos; si no, removemos
    if (user) localStorage.setItem('auth_user', JSON.stringify(user)) // Guardamos usuario
    else localStorage.removeItem('auth_user') // Eliminamos usuario
  }, [user])

  // Función auxiliar: cabeceras de autorización
  const makeAuthHeader = (t = token) => ({ Authorization: `Bearer ${t}` }) // Construimos header Bearer

  // Login usando Axios
  async function login({ email, password }) {
    setLoading(true)
    try {
      // Ejecutamos POST al endpoint de login de Xano
      const { data } = await axios.post(`${AUTH_BASE}/auth/login`, { email, password }) // Petición de login
      // Suponemos que la respuesta incluye token y datos del usuario
      const newToken = data?.authToken || data?.token || data?.jwt || '' // Extraemos token
      const newUser = data?.user || data?.profile || { name: data?.name || email } // Extraemos usuario
      // Actualizamos estados
      setToken(newToken) // Guardamos token
      setUser(newUser) // Guardamos usuario
      
      // Redirigir según el rol
      if (newUser.status === 'blocked') {
        navigate('/blocked')
      } else if (newUser.role === 'admin') {
        navigate('/admin')
      } else if (newUser.role === 'vendor') {
        navigate('/vendedor')
      } else {
        navigate('/')
      }
      
      // Devolvemos datos para uso adicional
      return { token: newToken, user: newUser } // Retornamos resultado
    } catch (error) {
      console.error('Error en login:', error)
      throw error
    } finally {
      setLoading(false)
    }
  }
  
  // Función para cerrar sesión
  function logout() {
    setToken('')
    setUser(null)
    localStorage.removeItem('auth_token')
    localStorage.removeItem('auth_user')
    localStorage.removeItem('auth_exp')
    navigate('/login')
  }
  
  // Verificar si el usuario tiene un rol específico
  function hasRole(role) {
    if (!user) return false
    if (role === 'admin' && user.role === 'admin') return true
    if (role === 'vendor' && (user.role === 'vendor' || user.role === 'admin')) return true
    if (role === 'cliente') return !!user
    return false
  }
  
  // Verificar si el usuario está bloqueado
  function isBlocked() {
    return user?.status === 'blocked'
  }
  
  // Verificar si el token ha expirado
  const isExpired = useMemo(() => {
    if (!expiresAt) return true
    return Date.now() >= expiresAt
  }, [expiresAt])
  
  // Verificar si el usuario está autenticado
  const isAuthenticated = useMemo(() => {
    return !!token && !!user && !isExpired
  }, [token, user, isExpired])

  // Valores y funciones que expondremos en el contexto
  const contextValue = {
    token,
    user,
    loading,
    isAuthenticated,
    isExpired,
    login,
    logout,
    hasRole,
    isBlocked,
    makeAuthHeader
  }

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  )
}

// Hook personalizado para usar el contexto de autenticación
export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth debe usarse dentro de un AuthProvider')
  }
  return context
}