import { createContext, useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const STORE_BASE = import.meta.env.VITE_XANO_STORE_BASE;

export const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const { isAuthenticated, token, makeAuthHeader } = useAuth();

  // Cargar carrito al iniciar sesión
  useEffect(() => {
    if (isAuthenticated) {
      fetchCart();
    } else {
      setCartItems([]);
    }
  }, [isAuthenticated]);

  // Obtener carrito del servidor
  const fetchCart = async () => {
    if (!isAuthenticated) return;
    
    setLoading(true);
    try {
      const { data } = await axios.get(`${STORE_BASE}/cart/me`, {
        headers: makeAuthHeader(token)
      });
      
      setCartItems(data.items || []);
    } catch (error) {
      console.error('Error al cargar el carrito:', error);
    } finally {
      setLoading(false);
    }
  };

  // Agregar producto al carrito
  const addToCart = async (productId, quantity) => {
    if (!isAuthenticated) return;
    
    setLoading(true);
    try {
      await axios.post(`${STORE_BASE}/cart/item`, 
        { product_id: productId, quantity }, 
        { headers: makeAuthHeader(token) }
      );
      
      // Recargar carrito después de agregar
      await fetchCart();
    } catch (error) {
      console.error('Error al agregar al carrito:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Actualizar cantidad de un producto
  const updateQuantity = async (itemId, quantity) => {
    if (!isAuthenticated) return;
    
    setLoading(true);
    try {
      await axios.patch(`${STORE_BASE}/cart/item/${itemId}`, 
        { quantity }, 
        { headers: makeAuthHeader(token) }
      );
      
      // Recargar carrito después de actualizar
      await fetchCart();
    } catch (error) {
      console.error('Error al actualizar cantidad:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Eliminar producto del carrito
  const removeFromCart = async (itemId) => {
    if (!isAuthenticated) return;
    
    setLoading(true);
    try {
      await axios.delete(`${STORE_BASE}/cart/item/${itemId}`, {
        headers: makeAuthHeader(token)
      });
      
      // Recargar carrito después de eliminar
      await fetchCart();
    } catch (error) {
      console.error('Error al eliminar del carrito:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Calcular total del carrito
  const cartTotal = cartItems.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0);

  return (
    <CartContext.Provider value={{
      cartItems,
      loading,
      cartTotal,
      addToCart,
      updateQuantity,
      removeFromCart,
      fetchCart
    }}>
      {children}
    </CartContext.Provider>
  );
}

// Hook para usar el contexto del carrito
export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart debe ser usado dentro de un CartProvider');
  }
  return context;
}