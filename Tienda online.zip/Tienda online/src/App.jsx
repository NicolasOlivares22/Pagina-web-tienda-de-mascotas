import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { CartProvider } from './context/CartContext'
import { ProtectedRoute, RoleRoute } from './components/ProtectedRoute'
import Navbar from './components/Navbar'

// Páginas públicas
import Home from './pages/Home'
import Login from './pages/Login'
import Products from './pages/Products'
import ProductDetail from './pages/ProductDetail'

// Páginas de cliente
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import Account from './pages/Account'
import Orders from './pages/Orders'
import Blocked from './pages/Blocked'
import Unauthorized from './pages/Unauthorized'

// Páginas de vendedor
import VendorDashboard from './pages/vendor/VendorDashboard'
import VendorProducts from './pages/vendor/VendorProducts'
import VendorProductForm from './pages/vendor/VendorProductForm'

// Páginas de administrador
import AdminDashboard from './pages/admin/AdminDashboard'
import AdminProducts from './pages/admin/AdminProducts'
import AdminOrders from './pages/admin/AdminOrders'
import AdminOrderDetail from './pages/admin/AdminOrderDetail'
import AdminUsers from './pages/admin/AdminUsers'

function App() {
  return (
      <AuthProvider>
        <CartProvider>
          <Navbar />
          <div className="container py-4">
            <Routes>
              {/* Rutas públicas */}
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/productos" element={<Products />} />
              <Route path="/producto/:id" element={<ProductDetail />} />
              <Route path="/blocked" element={<Blocked />} />
              <Route path="/unauthorized" element={<Unauthorized />} />

              {/* Rutas protegidas para clientes */}
              <Route element={<ProtectedRoute />}>
                <Route path="/carrito" element={<Cart />} />
                <Route path="/checkout" element={<Checkout />} />
                <Route path="/cuenta" element={<Account />} />
                <Route path="/cuenta/ordenes" element={<Orders />} />
              </Route>

              {/* Rutas protegidas para vendedores */}
              <Route element={<RoleRoute requiredRole="vendor" />}>
                <Route path="/vendedor" element={<VendorDashboard />} />
                <Route path="/vendedor/productos" element={<VendorProducts />} />
                <Route path="/vendedor/productos/nuevo" element={<VendorProductForm />} />
                <Route path="/vendedor/productos/:id/editar" element={<VendorProductForm />} />
              </Route>

              {/* Rutas protegidas para administradores */}
              <Route element={<RoleRoute requiredRole="admin" />}>
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="/admin/productos" element={<AdminProducts />} />
                <Route path="/admin/ordenes" element={<AdminOrders />} />
                <Route path="/admin/ordenes/:id" element={<AdminOrderDetail />} />
                <Route path="/admin/usuarios" element={<AdminUsers />} />
              </Route>

              {/* Ruta por defecto */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </CartProvider>
      </AuthProvider>
  )
}

export default App
